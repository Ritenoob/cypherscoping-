/**
 * Dynamic Coin List Manager
 * 
 * Features:
 * - Fetches active contracts from KuCoin Futures
 * - Ranks by 24h volume, open interest, volatility
 * - Auto-refreshes hourly
 * - Tiered coin classification
 */

const axios = require('axios');

const KUCOIN_FUTURES_REST = 'https://api-futures.kucoin.com';

class CoinListManager {
  constructor(config = {}) {
    this.minVolume = config.minVolume || 10_000_000;
    this.maxSpread = config.maxSpread || 0.05;
    this.topN = config.topN || 50;
    this.refreshInterval = config.refreshInterval || 60 * 60 * 1000;
    
    this.coins = [];
    this.tiers = { tier1: [], tier2: [], tier3: [] };
    this.lastUpdate = null;
    this.refreshTimer = null;
  }

  async initialize() {
    await this.refresh();
    
    this.refreshTimer = setInterval(() => {
      this.refresh().catch(err => {
        console.error('[CoinList] Refresh failed:', err.message);
      });
    }, this.refreshInterval);
    
    console.log(`[CoinList] Initialized with ${this.coins.length} coins`);
  }

  async refresh() {
    try {
      const contractsResponse = await axios.get(`${KUCOIN_FUTURES_REST}/api/v1/contracts/active`);
      
      if (contractsResponse.data.code !== '200000') {
        throw new Error(`API error: ${contractsResponse.data.msg}`);
      }
      
      const contracts = contractsResponse.data.data;
      
      const usdtPerps = contracts.filter(c => 
        c.quoteCurrency === 'USDT' && 
        c.isInverse === false &&
        c.status === 'Open'
      );
      
      const withStats = await Promise.all(
        usdtPerps.map(async (contract) => {
          try {
            const tickerResponse = await axios.get(
              `${KUCOIN_FUTURES_REST}/api/v1/ticker?symbol=${contract.symbol}`
            );
            
            const ticker = tickerResponse.data.data;
            
            return {
              symbol: contract.symbol,
              baseCurrency: contract.baseCurrency,
              volume24h: parseFloat(ticker?.vol24h || 0),
              turnover24h: parseFloat(ticker?.turnover24h || 0),
              priceChangePercent: parseFloat(ticker?.priceChgPct || 0) * 100,
              lastPrice: parseFloat(ticker?.price || 0),
              bestBid: parseFloat(ticker?.bestBidPrice || 0),
              bestAsk: parseFloat(ticker?.bestAskPrice || 0),
              openInterest: parseFloat(contract.openInterest || 0),
              lotSize: contract.lotSize,
              multiplier: contract.multiplier,
              maxLeverage: contract.maxLeverage,
              fundingRate: parseFloat(contract.fundingFeeRate || 0)
            };
          } catch (err) {
            return null;
          }
        })
      );
      
      this.coins = withStats
        .filter(c => c !== null)
        .filter(c => c.turnover24h >= this.minVolume)
        .filter(c => {
          if (c.bestBid > 0 && c.bestAsk > 0) {
            const spread = (c.bestAsk - c.bestBid) / c.bestBid * 100;
            return spread <= this.maxSpread;
          }
          return true;
        })
        .sort((a, b) => b.turnover24h - a.turnover24h)
        .slice(0, this.topN);
      
      this.tiers = {
        tier1: this.coins.slice(0, 5),
        tier2: this.coins.slice(5, 15),
        tier3: this.coins.slice(15, 30)
      };
      
      this.lastUpdate = Date.now();
      
      console.log(`[CoinList] Refreshed: ${this.coins.length} coins`);
      console.log(`[CoinList] Tier 1: ${this.tiers.tier1.map(c => c.symbol).join(', ')}`);
      
      return this.coins;
    } catch (error) {
      console.error('[CoinList] Refresh error:', error.message);
      throw error;
    }
  }

  getTopCoins(count = 20) {
    return this.coins.slice(0, count);
  }

  getTieredCoins() {
    return this.tiers;
  }

  getSymbols() {
    return this.coins.map(c => c.symbol);
  }

  getCoinData(symbol) {
    return this.coins.find(c => c.symbol === symbol);
  }

  stop() {
    if (this.refreshTimer) {
      clearInterval(this.refreshTimer);
    }
  }
}

module.exports = new CoinListManager();
