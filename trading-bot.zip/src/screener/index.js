/**
 * Screener Module Exports
 */

const CoinRankerV2 = require('./CoinRankerV2');

module.exports = {
  CoinRankerV2
};
