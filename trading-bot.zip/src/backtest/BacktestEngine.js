/**
 * Backtest Engine
 * 
 * Historical strategy testing with:
 * - Candle-by-candle simulation
 * - Realistic slippage and fees
 * - Walk-forward validation
 * - Performance metrics calculation
 */

const Decimal = require('decimal.js');
const PositionCalculator = require('../utils/PositionCalculator');
const SignalGeneratorV2 = require('../lib/SignalGeneratorV2');

class BacktestEngine {
  constructor(config = {}) {
    this.initialBalance = config.initialBalance || 10000;
    this.leverage = config.leverage || 50;
    this.riskPerTrade = config.riskPerTrade || 2;
    this.slippage = config.slippage || 0.0005;
    this.commission = config.commission || 0.0006;
    
    this.positionCalc = new PositionCalculator({
      leverage: this.leverage,
      takerFee: this.commission
    });
    
    this.signalGenerator = new SignalGeneratorV2({
      enhancedMode: true,
      includeMicrostructure: false
    });
    
    this.reset();
  }

  reset() {
    this.balance = new Decimal(this.initialBalance);
    this.equity = [{ ts: 0, value: this.initialBalance }];
    this.positions = [];
    this.trades = [];
    this.stats = {
      totalTrades: 0,
      winningTrades: 0,
      losingTrades: 0,
      totalPnL: 0,
      maxDrawdown: 0,
      peakEquity: this.initialBalance
    };
  }

  async runBacktest(candles, indicators, config = {}) {
    this.reset();
    
    const warmupPeriod = config.warmupPeriod || 50;
    const stopLossROI = config.stopLossROI || 0.5;
    const takeProfitROI = config.takeProfitROI || 2.0;
    
    for (let i = warmupPeriod; i < candles.length; i++) {
      const candle = candles[i];
      const indicatorValues = this._getIndicatorValuesAtIndex(indicators, i);
      
      this._checkExits(candle);
      
      if (this.positions.length === 0) {
        const signal = this.signalGenerator.generate(indicatorValues, {});
        
        if (signal.type.includes('BUY') && Math.abs(signal.indicatorScore) >= 50) {
          this._openPosition(candle, 'long', stopLossROI, takeProfitROI);
        } else if (signal.type.includes('SELL') && Math.abs(signal.indicatorScore) >= 50) {
          this._openPosition(candle, 'short', stopLossROI, takeProfitROI);
        }
      }
      
      const currentEquity = this._calculateEquity(candle.close);
      this.equity.push({ ts: candle.ts, value: currentEquity.toNumber() });
      
      if (currentEquity.greaterThan(this.stats.peakEquity)) {
        this.stats.peakEquity = currentEquity.toNumber();
      }
      
      const drawdown = new Decimal(this.stats.peakEquity)
        .minus(currentEquity)
        .div(this.stats.peakEquity)
        .toNumber();
      
      if (drawdown > this.stats.maxDrawdown) {
        this.stats.maxDrawdown = drawdown;
      }
    }
    
    this._closeAllPositions(candles[candles.length - 1]);
    
    return this._calculateResults();
  }

  _getIndicatorValuesAtIndex(indicators, index) {
    const values = {};
    
    for (const [name, history] of Object.entries(indicators)) {
      if (Array.isArray(history) && index < history.length) {
        values[name] = history[index];
      }
    }
    
    return values;
  }

  _openPosition(candle, side, stopLossROI, takeProfitROI) {
    const slippageMultiplier = side === 'long' ? 1 + this.slippage : 1 - this.slippage;
    const entryPrice = new Decimal(candle.close).mul(slippageMultiplier).toNumber();
    
    const positionDetails = this.positionCalc.calculatePosition({
      balance: this.balance.toNumber(),
      riskPercent: this.riskPerTrade,
      entryPrice,
      leverage: this.leverage,
      side,
      stopLossROI,
      takeProfitROI
    });
    
    this.positions.push({
      id: `pos-${Date.now()}`,
      symbol: 'BACKTEST',
      side,
      entryPrice,
      size: positionDetails.size,
      stopLoss: positionDetails.stopLoss,
      takeProfit: positionDetails.takeProfit,
      entryTime: candle.ts,
      margin: positionDetails.margin
    });
    
    const entryFee = new Decimal(positionDetails.notional).mul(this.commission);
    this.balance = this.balance.minus(entryFee);
  }

  _checkExits(candle) {
    const toClose = [];
    
    for (const position of this.positions) {
      let shouldClose = false;
      let exitPrice = null;
      let reason = '';
      
      if (position.side === 'long') {
        if (candle.low <= position.stopLoss) {
          shouldClose = true;
          exitPrice = position.stopLoss;
          reason = 'stop_loss';
        } else if (candle.high >= position.takeProfit) {
          shouldClose = true;
          exitPrice = position.takeProfit;
          reason = 'take_profit';
        }
      } else {
        if (candle.high >= position.stopLoss) {
          shouldClose = true;
          exitPrice = position.stopLoss;
          reason = 'stop_loss';
        } else if (candle.low <= position.takeProfit) {
          shouldClose = true;
          exitPrice = position.takeProfit;
          reason = 'take_profit';
        }
      }
      
      if (shouldClose) {
        toClose.push({ position, exitPrice, reason, exitTime: candle.ts });
      }
    }
    
    for (const { position, exitPrice, reason, exitTime } of toClose) {
      this._closePosition(position, exitPrice, reason, exitTime);
    }
  }

  _closePosition(position, exitPrice, reason, exitTime) {
    const slippageMultiplier = position.side === 'long' ? 1 - this.slippage : 1 + this.slippage;
    const adjustedExitPrice = new Decimal(exitPrice).mul(slippageMultiplier).toNumber();
    
    const roi = this.positionCalc.calculateROI({
      entryPrice: position.entryPrice,
      exitPrice: adjustedExitPrice,
      leverage: this.leverage,
      side: position.side
    });
    
    const pnl = new Decimal(position.margin).mul(roi.netROI).div(100);
    this.balance = this.balance.plus(pnl);
    
    this.stats.totalTrades++;
    this.stats.totalPnL += pnl.toNumber();
    
    if (pnl.greaterThan(0)) {
      this.stats.winningTrades++;
    } else {
      this.stats.losingTrades++;
    }
    
    this.trades.push({
      ...position,
      exitPrice: adjustedExitPrice,
      exitTime,
      reason,
      pnl: pnl.toNumber(),
      roi: roi.netROI
    });
    
    this.positions = this.positions.filter(p => p.id !== position.id);
  }

  _closeAllPositions(candle) {
    for (const position of [...this.positions]) {
      this._closePosition(position, candle.close, 'end_of_backtest', candle.ts);
    }
  }

  _calculateEquity(currentPrice) {
    let equity = this.balance;
    
    for (const position of this.positions) {
      const unrealizedPnl = this._calculateUnrealizedPnL(position, currentPrice);
      equity = equity.plus(unrealizedPnl);
    }
    
    return equity;
  }

  _calculateUnrealizedPnL(position, currentPrice) {
    const entryD = new Decimal(position.entryPrice);
    const currentD = new Decimal(currentPrice);
    
    let pnlPercent;
    if (position.side === 'long') {
      pnlPercent = currentD.minus(entryD).div(entryD);
    } else {
      pnlPercent = entryD.minus(currentD).div(entryD);
    }
    
    return new Decimal(position.margin).mul(pnlPercent).mul(this.leverage);
  }

  _calculateResults() {
    const finalBalance = this.balance.toNumber();
    const totalReturn = ((finalBalance - this.initialBalance) / this.initialBalance) * 100;
    
    const winRate = this.stats.totalTrades > 0
      ? (this.stats.winningTrades / this.stats.totalTrades) * 100
      : 0;
    
    const winners = this.trades.filter(t => t.pnl > 0);
    const losers = this.trades.filter(t => t.pnl < 0);
    
    const avgWin = winners.length > 0
      ? winners.reduce((s, t) => s + t.pnl, 0) / winners.length
      : 0;
    
    const avgLoss = losers.length > 0
      ? Math.abs(losers.reduce((s, t) => s + t.pnl, 0) / losers.length)
      : 1;
    
    const profitFactor = avgLoss > 0 ? avgWin / avgLoss : avgWin;
    
    const returns = [];
    for (let i = 1; i < this.equity.length; i++) {
      const ret = (this.equity[i].value - this.equity[i-1].value) / this.equity[i-1].value;
      returns.push(ret);
    }
    
    const avgReturn = returns.length > 0
      ? returns.reduce((a, b) => a + b, 0) / returns.length
      : 0;
    
    const stdReturn = returns.length > 0
      ? Math.sqrt(returns.reduce((sum, r) => sum + Math.pow(r - avgReturn, 2), 0) / returns.length)
      : 1;
    
    const sharpeRatio = stdReturn > 0
      ? (avgReturn * Math.sqrt(252 * 24)) / (stdReturn * Math.sqrt(252 * 24))
      : 0;
    
    return {
      initialBalance: this.initialBalance,
      finalBalance,
      totalReturn: totalReturn.toFixed(2),
      totalTrades: this.stats.totalTrades,
      winningTrades: this.stats.winningTrades,
      losingTrades: this.stats.losingTrades,
      winRate: winRate.toFixed(2),
      profitFactor: profitFactor.toFixed(2),
      sharpeRatio: sharpeRatio.toFixed(2),
      maxDrawdown: (this.stats.maxDrawdown * 100).toFixed(2),
      avgWin: avgWin.toFixed(2),
      avgLoss: avgLoss.toFixed(2),
      trades: this.trades,
      equity: this.equity
    };
  }
}

module.exports = BacktestEngine;
