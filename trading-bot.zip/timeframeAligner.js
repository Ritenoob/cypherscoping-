/**
 * Timeframe Aligner
 * 
 * Cross-timeframe signal confirmation system.
 * Validates signals across primary and secondary timeframes
 * to reduce false signals and improve accuracy.
 */

const SignalGeneratorV2 = require('./src/lib/SignalGeneratorV2');

class TimeframeAligner {
  constructor(config = {}) {
    this.primaryWeight = config.primaryWeight || 0.6;
    this.secondaryWeight = config.secondaryWeight || 0.4;
    this.maxDivergence = config.maxDivergence || 30;
    this.requireBoth = config.requireBoth !== false;
    
    this.signalGenerator = new SignalGeneratorV2({
      enhancedMode: true,
      includeMicrostructure: false // TF alignment uses indicators only
    });
  }

  /**
   * Check alignment between two timeframes
   * 
   * @param {Object} primaryIndicators - Primary timeframe indicator results
   * @param {Object} secondaryIndicators - Secondary timeframe indicator results
   * @param {Object} config - Additional configuration
   * @returns {Object|null} Aligned signal or null if not aligned
   */
  checkAlignment(primaryIndicators, secondaryIndicators, config = {}) {
    // Generate signals for each timeframe
    const primarySignal = this.signalGenerator.generate(primaryIndicators, {});
    const secondarySignal = this.signalGenerator.generate(secondaryIndicators, {});
    
    // Check if both have valid signals
    if (primarySignal.type === 'NEUTRAL' && secondarySignal.type === 'NEUTRAL') {
      return null;
    }
    
    // Calculate combined score
    const combinedScore = this._calculateCombinedScore(primarySignal, secondarySignal);
    
    // Check direction alignment
    const alignment = this._checkDirectionAlignment(primarySignal, secondarySignal);
    
    if (!alignment.aligned && this.requireBoth) {
      return null;
    }
    
    // Check score divergence
    const divergence = Math.abs(primarySignal.indicatorScore - secondarySignal.indicatorScore);
    if (divergence > this.maxDivergence && this.requireBoth) {
      return null;
    }
    
    // Determine final direction
    const direction = this._determineDirection(combinedScore);
    if (!direction) return null;
    
    // Combine signals from both timeframes
    const combinedSignals = this._combineSignals(primarySignal, secondarySignal);
    
    // Calculate confidence based on alignment
    const confidence = this._calculateConfidence(primarySignal, secondarySignal, alignment);
    
    return {
      direction,
      score: combinedScore,
      confidence,
      primaryScore: primarySignal.indicatorScore,
      secondaryScore: secondarySignal.indicatorScore,
      divergence,
      alignment: alignment.type,
      indicators: {
        primary: primarySignal.breakdown.indicators,
        secondary: secondarySignal.breakdown.indicators
      },
      signals: combinedSignals
    };
  }

  _calculateCombinedScore(primary, secondary) {
    return Math.round(
      primary.indicatorScore * this.primaryWeight +
      secondary.indicatorScore * this.secondaryWeight
    );
  }

  _checkDirectionAlignment(primary, secondary) {
    const primaryDir = this._getDirection(primary.type);
    const secondaryDir = this._getDirection(secondary.type);
    
    if (primaryDir === secondaryDir) {
      return { aligned: true, type: 'full' };
    }
    
    if (primaryDir === 'neutral' || secondaryDir === 'neutral') {
      return { aligned: true, type: 'partial' };
    }
    
    return { aligned: false, type: 'divergent' };
  }

  _getDirection(signalType) {
    if (signalType.includes('BUY')) return 'bullish';
    if (signalType.includes('SELL')) return 'bearish';
    return 'neutral';
  }

  _determineDirection(score) {
    if (score >= 30) return 'long';
    if (score <= -30) return 'short';
    return null;
  }

  _combineSignals(primary, secondary) {
    const combined = [];
    const seen = new Set();
    
    // Add primary signals with higher priority
    for (const signal of primary.signals) {
      const key = `${signal.type}-${signal.direction}`;
      if (!seen.has(key)) {
        combined.push({ ...signal, timeframe: 'primary' });
        seen.add(key);
      }
    }
    
    // Add secondary signals
    for (const signal of secondary.signals) {
      const key = `${signal.type}-${signal.direction}`;
      if (!seen.has(key)) {
        combined.push({ ...signal, timeframe: 'secondary' });
        seen.add(key);
      }
    }
    
    return combined;
  }

  _calculateConfidence(primary, secondary, alignment) {
    let confidence = 0;
    
    // Base confidence from individual signals
    confidence += primary.confidence * 0.5;
    confidence += secondary.confidence * 0.5;
    
    // Bonus for alignment
    if (alignment.type === 'full') {
      confidence += 20;
    } else if (alignment.type === 'partial') {
      confidence += 10;
    } else {
      confidence -= 20;
    }
    
    // Clamp to valid range
    return Math.max(0, Math.min(100, Math.round(confidence)));
  }

  /**
   * Get alignment status for display
   */
  getAlignmentStatus(result) {
    if (!result) return 'NO_SIGNAL';
    
    if (result.alignment === 'full' && result.confidence >= 60) {
      return 'STRONG_ALIGNMENT';
    }
    
    if (result.alignment === 'partial' && result.confidence >= 40) {
      return 'PARTIAL_ALIGNMENT';
    }
    
    if (result.alignment === 'divergent') {
      return 'DIVERGENT';
    }
    
    return 'WEAK_ALIGNMENT';
  }
}

// Export singleton for shared use
module.exports = new TimeframeAligner();
