/**
 * Signal Weights Configuration
 * 
 * Defines weight distribution for all 10 indicators + 3 microstructure analyzers
 * Total indicator weight: 160 (capped at ±110)
 * Total microstructure weight: 45 (capped at ±20)
 * Final score range: -130 to +130
 */

module.exports = {
  // Technical Indicators (10 total)
  indicators: {
    rsi: {
      maxWeight: 25,
      enabled: true,
      signals: {
        crossover: { weight: 1.0, priority: 2 },
        divergence: { weight: 1.2, priority: 1 },
        momentum: { weight: 0.7, priority: 3 },
        zone: { weight: 0.7, priority: 4 }
      }
    },
    
    macd: {
      maxWeight: 20,
      enabled: true,
      signals: {
        signal_crossover: { weight: 1.0, priority: 2 },
        zero_crossover: { weight: 1.0, priority: 2 },
        histogram: { weight: 0.7, priority: 3 },
        divergence: { weight: 1.2, priority: 1 }
      }
    },
    
    williamsR: {
      maxWeight: 20,
      enabled: true,
      signals: {
        crossover: { weight: 1.0, priority: 2 },
        failure_swing: { weight: 0.7, priority: 3 },
        divergence: { weight: 1.2, priority: 1 },
        zone: { weight: 0.7, priority: 4 }
      }
    },
    
    ao: {
      maxWeight: 15,
      enabled: true,
      signals: {
        zero_cross: { weight: 1.0, priority: 2 },
        saucer: { weight: 0.7, priority: 3 },
        twin_peaks: { weight: 1.0, priority: 2 },
        divergence: { weight: 1.2, priority: 1 }
      }
    },
    
    emaTrend: {
      maxWeight: 20,
      enabled: true,
      signals: {
        ema_cross: { weight: 1.0, priority: 2 },
        golden_death_cross: { weight: 1.2, priority: 1 },
        trend_direction: { weight: 0.7, priority: 3 },
        slope: { weight: 0.7, priority: 4 }
      }
    },
    
    stochastic: {
      maxWeight: 10,
      enabled: true,
      signals: {
        kd_crossover: { weight: 1.0, priority: 2 },
        zone: { weight: 0.7, priority: 3 },
        divergence: { weight: 1.2, priority: 1 }
      }
    },
    
    bollinger: {
      maxWeight: 10,
      enabled: true,
      signals: {
        band_touch: { weight: 0.7, priority: 3 },
        squeeze: { weight: 1.0, priority: 2 },
        breakout: { weight: 1.0, priority: 2 },
        percentB: { weight: 0.5, priority: 4 }
      }
    },
    
    kdj: {
      maxWeight: 15,
      enabled: true,
      signals: {
        j_line: { weight: 1.0, priority: 2 },
        kd_cross: { weight: 0.7, priority: 3 },
        divergence: { weight: 1.2, priority: 1 }
      }
    },
    
    obv: {
      maxWeight: 10,
      enabled: true,
      signals: {
        slope: { weight: 0.7, priority: 3 },
        breakout: { weight: 1.0, priority: 2 },
        divergence: { weight: 1.2, priority: 1 }
      }
    },
    
    dom: {
      maxWeight: 15,
      enabled: true,
      liveOnly: true,
      signals: {
        imbalance: { weight: 1.0, priority: 2 },
        wall: { weight: 0.7, priority: 3 },
        microprice: { weight: 0.5, priority: 4 }
      }
    }
  },
  
  // Microstructure Analyzers (3 total) - LIVE ONLY
  microstructure: {
    buySellRatio: {
      maxWeight: 15,
      enabled: true,
      liveOnly: true,
      signals: {
        flow_imbalance: { weight: 1.0, priority: 2 },
        absorption: { weight: 0.7, priority: 3 },
        exhaustion: { weight: 1.0, priority: 2 },
        delta_momentum: { weight: 0.7, priority: 3 }
      }
    },
    
    priceRatio: {
      maxWeight: 15,
      enabled: true,
      liveOnly: true,
      signals: {
        basis: { weight: 1.0, priority: 2 },
        spread: { weight: 1.0, priority: 2 },
        convergence: { weight: 0.7, priority: 3 },
        bid_ask_imbalance: { weight: 0.5, priority: 4 },
        mark_deviation: { weight: 0.5, priority: 4 }
      }
    },
    
    fundingRate: {
      maxWeight: 15,
      enabled: true,
      liveOnly: true,
      signals: {
        extreme_rate: { weight: 1.2, priority: 1 },
        rate_change: { weight: 0.7, priority: 3 },
        predicted_rate: { weight: 0.7, priority: 3 },
        funding_timing: { weight: 1.0, priority: 2 },
        cumulative: { weight: 0.7, priority: 3 }
      }
    }
  },
  
  // Strength multipliers
  strengthMultipliers: {
    very_strong: 1.2,
    strong: 1.0,
    moderate: 0.7,
    weak: 0.5,
    extreme: 1.1
  },
  
  // Score caps
  caps: {
    indicatorScore: 110,
    microstructureScore: 20,
    totalScore: 130
  },
  
  // Signal classifications
  classifications: {
    EXTREME_BUY: { min: 90, max: 130 },
    STRONG_BUY: { min: 70, max: 89 },
    BUY: { min: 50, max: 69 },
    BUY_WEAK: { min: 30, max: 49 },
    NEUTRAL: { min: -29, max: 29 },
    SELL_WEAK: { min: -49, max: -30 },
    SELL: { min: -69, max: -50 },
    STRONG_SELL: { min: -89, max: -70 },
    EXTREME_SELL: { min: -130, max: -90 }
  }
};
